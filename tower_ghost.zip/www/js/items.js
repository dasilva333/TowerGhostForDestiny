var Item = function(model, profile){
	var self = this;
	_.each(model, function(value, key){
		self[key] = value;
	});
	this.character = profile;
	this.href = "https://destinydb.com/items/" + self.id;
	this.isEquipped = ko.observable(self.isEquipped);
	this.setActiveItem = function(){
		app.activeItem(self);
	}
	this.primaryStat = self.primaryStat || "";
	this.isVisible = ko.computed(this._isVisible, this);
	this.isEquippable = function(avatarId){
		return ko.computed(function(){
			 return (!self.isEquipped() && avatarId !== 'Vault' && self.bucketType != 'Materials' && self.bucketType != 'Consumables' && self.description.indexOf("Engram") == -1) || 
			 	(self.characterId != avatarId && avatarId !== 'Vault' && self.bucketType != 'Materials' && self.bucketType != 'Consumables' && self.description.indexOf("Engram") == -1);
		});
	}
}

Item.prototype = {
	hasPerkSearch: function(search){
		var foundPerk = false, self = this;
		if (self.perks){
			var vSearch = search.toLowerCase();
			self.perks.forEach(function(perk){
				if (perk.name.toLowerCase().indexOf(vSearch) > -1 || perk.description.toLowerCase().indexOf(vSearch) > -1)
					foundPerk = true;
			});
		}
		return foundPerk;
	},
	hashProgress: function(state){
		var self = this;
		if (typeof self.progression !== "undefined"){
			/* Missing XP */
			if (state == 1 && self.progression == false){
				return true;
			}
			/* Full XP  but not maxed out */
			else if (state == 2 && self.progression == true && self.isGridComplete == false){
				return true
			}
			/* Maxed weapons (Gold Borders only) */
			else if (state == 3 && self.progression == true && self.isGridComplete == true){
				return true;
			}
			else {
				return false;
			}
		}
		else {
			return false;
		}
	},
	_isVisible: function(){
		var $parent = app, self = this;
		var searchFilter = $parent.searchKeyword() == '' || self.hasPerkSearch($parent.searchKeyword()) || 
			($parent.searchKeyword() !== "" && self.description.toLowerCase().indexOf($parent.searchKeyword().toLowerCase()) >-1);
		var dmgFilter = $parent.dmgFilter().length ==0 || $parent.dmgFilter().indexOf(self.damageTypeName) > -1;
		var setFilter = $parent.setFilter().length == 0 || $parent.setFilter().indexOf(self.id) > -1 || $parent.setFilterFix().indexOf(self.id) > -1;
		var tierFilter = $parent.tierFilter() == 0 || $parent.tierFilter() == self.tierType;
		var progressFilter = $parent.progressFilter() == 0 || self.hashProgress($parent.progressFilter());
		var typeFilter = $parent.typeFilter() == 0 || $parent.typeFilter() == self.type;
		var uniqueFilter = $parent.showUniques() == false || ($parent.showUniques() == true && self.isUnique);
		/*console.log( "searchFilter: " + searchFilter);
		console.log( "dmgFilter: " + dmgFilter);
		console.log( "setFilter: " + setFilter);
		console.log( "tierFilter: " + tierFilter);
		console.log( "progressFilter: " + progressFilter);
		console.log( "typeFilter: " + typeFilter);
		console.log("keyword is: " + $parent.searchKeyword());
		console.log("keyword is empty " + ($parent.searchKeyword() == ''));
		console.log("keyword has perk " + self.hasPerkSearch($parent.searchKeyword()));
		console.log("perks are " + JSON.stringify(self.perks));
		console.log("description is " + self.description);
		console.log("keyword has description " + ($parent.searchKeyword() !== "" && self.description.toLowerCase().indexOf($parent.searchKeyword().toLowerCase()) >-1));*/
		return (searchFilter) && (dmgFilter) && (setFilter) && (tierFilter) && (progressFilter) && (typeFilter) && (uniqueFilter);
	},
	/* helper function that unequips the current item in favor of anything else */
	unequip: function(callback){
		var self = this;
		//console.log('trying to unequip too!');
		if (self.isEquipped() == true){
			//console.log("and its actually equipped");
			var otherEquipped = false, itemIndex = -1;
			var otherItems = _.filter(_.where( self.character.items(), { bucketType: self.bucketType }), function(item){
				return item.tierType != 6;
			});
			if ( otherItems.length > 0){
				var tryNextItem = function(){			
					var item = otherItems[++itemIndex];
					//console.log(item.description);
					/* still haven't found a match */
					if (otherEquipped == false){
						if (item != self){
							//console.log("trying to equip " + item.description);
							item.equip(self.characterId, function(isEquipped){
								//console.log( item.description + " result was " + isEquipped);
								if (isEquipped == true){ otherEquipped = true; callback(); }
								else { tryNextItem(); /*console.log("tryNextItem")*/ }
							});				
						}
						else {
							tryNextItem()
							//console.log("tryNextItem")
						}
					}
				}
				//console.log("tryNextItem")
				tryNextItem();			
			}
			else {
				callback(false);
			}
		}
		else {
			//console.log("but not equipped");
			callback();
		}
	},
	equip: function(targetCharacterId, callback, allowReplacement){
		var self = this;
		var done = function(){
			//console.log("making bungie call to equip " + self.description);
			app.bungie.equip(targetCharacterId, self._id, function(e, result){
				if (result.Message == "Ok"){
					//console.log("result was OKed");
					//console.log(result);
					self.isEquipped(true);
					self.character.items().forEach(function(item){
						if (item != self && item.bucketType == self.bucketType){
							item.isEquipped(false);							
						}
					});
					if (self.bucketType == "Emblem"){
						self.character.icon(app.makeBackgroundUrl(self.icon, true));
						self.character.background(self.backgroundPath);
					}
					if (callback) callback(true);
				}
				else {
					//console.log("result failed");
					/* this is by design if the user equips something they couldn't the app shouldn't assume a replacement unless it's via loadouts */
					if (callback) callback(false);
					else BootstrapDialog.alert(result.Message);
				}
			});		
		}
		//console.log("equip called");
		var sourceCharacterId = self.characterId;		
		if (targetCharacterId == sourceCharacterId){
			//console.log("item is already in the character");
			/* if item is exotic */
			if ( self.tierType == 6 && allowReplacement){
				//console.log("item is exotic");
				var otherExoticFound = false,
					otherBucketTypes = DestinyWeaponPieces.indexOf(self.bucketType) > -1 ? _.clone(DestinyWeaponPieces) :  _.clone(DestinyArmorPieces);
				otherBucketTypes.splice(DestinyWeaponPieces.indexOf(self.bucketType),1);
				//console.log("the other bucket types are " + JSON.stringify(otherBucketTypes));	
				_.each(otherBucketTypes, function(bucketType){
					var otherExotic = _.filter(_.where( self.character.items(), { bucketType: bucketType, tierType: 6 }), function(item){
						return item.isEquipped();
					});
					//console.log( "otherExotic: " + JSON.stringify(_.pluck(otherExotic,'description')) );
					if ( otherExotic.length > 0 ){
						//console.log("found another exotic equipped " + otherExotic[0].description);
						otherExoticFound = true;
						otherExotic[0].unequip(done);
					}					
				});
				if (otherExoticFound == false){
					done();
				}
			}
			else {
				//console.log("item is not exotic");
				done()
			}			
		}
		else {
			//console.log("item is NOT already in the character");
			self.store(targetCharacterId, function(newProfile){
				//console.log("item is now in the target destination");
				self.character = newProfile;
				self.characterId = newProfile.id;
				self.equip(targetCharacterId, callback, allowReplacement);
			});
		}
	},
	transfer: function(sourceCharacterId, targetCharacterId, amount, cb){		
		//console.log("Item.transfer");
		//console.log(arguments);
		//setTimeout(function(){
		var self = this;
			var isVault = targetCharacterId == "Vault";
			app.bungie.transfer(isVault ? sourceCharacterId : targetCharacterId, self._id, self.id, amount, isVault, function(e, result){
				//console.log("app.bungie.transfer after");
				//console.log(arguments);
				if (result.Message == "Ok"){
					var x,y;
					_.each(app.characters(), function(character){
						if (character.id == sourceCharacterId){
							//console.log("removing reference of myself ( " + self.description + " ) in " + character.classType + " from the list of " + self.list);
							x = character;
						}
						else if (character.id == targetCharacterId){
							//console.log("adding a reference of myself ( " + self.description + " ) to this guy " + character.classType);
							y = character;
						}
					});
					if (self.bucketType == "Materials" || self.bucketType == "Consumables"){
						//console.log("need to split reference of self and push it into x and y");
						var remainder = self.primaryStat - amount;
						/* at this point we can either add the item to the inventory or merge it with existing items there */
						var existingItem = _.findWhere( y.items(), { description: self.description });
						if (existingItem){
							y.items.remove(existingItem);
							existingItem.primaryStat = existingItem.primaryStat + amount;
							y.items.push(existingItem);
						}
						else {
							self.characterId = targetCharacterId
							self.character = y;
							self.primaryStat = amount;
							y.items.push(self);
						}
						/* the source item gets removed from the array, change the stack size, and add it back to the array if theres items left behind */
						x.items.remove(self);
						if (remainder > 0){
							self.characterId = sourceCharacterId
							self.character = x;
							self.primaryStat = remainder;
							x.items.push(self);
						}
					}
					else {
						self.characterId = targetCharacterId
						self.character = y;
						y.items.push(self);
						x.items.remove(self);
					}
					if (cb) cb(y,x);
				}
				else {
					BootstrapDialog.alert(result.Message);
				}
			});		
		//}, 1000);
	},
	store: function(targetCharacterId, callback){
		//console.log("item.store");
		//console.log(arguments);
		var self = this;
		var sourceCharacterId = self.characterId, transferAmount = 1;
		var done = function(){			
			if (targetCharacterId == "Vault"){
				//console.log("from character to vault");
				self.unequip(function(){
					//console.log("calling transfer from character to vault");
					self.transfer(sourceCharacterId, "Vault", transferAmount, callback);
				});
			}
			else if (sourceCharacterId !== "Vault"){
				//console.log("from character to vault to character");
				self.unequip(function(){
					//console.log("unquipped item");
					self.transfer(sourceCharacterId, "Vault", transferAmount, function(){
						//console.log("xfered item to vault");
						self.transfer("Vault", targetCharacterId, transferAmount, callback);
					});
				});
			}
			else {
				//console.log("from vault to character");
				self.transfer("Vault", targetCharacterId, transferAmount, callback);
			}		
		}
		if (self.bucketType == "Materials" || self.bucketType == "Consumables"){
			if (self.primaryStat == 1){
				done();
			}
			else if (app.autoTransferStacks() == true){
				transferAmount = self.primaryStat; 
				done();
			}
			else {				
				var dialogItself = (new dialog({
		            message: "<div>Transfer Amount: <input type='text' id='materialsAmount' value='" + self.primaryStat + "'></div>",
		            buttons: [
						{
		                	label: 'Transfer',
							cssClass: 'btn-primary',
							action: function(){
								finishTransfer()
							}
		            	}, 
						{
			                label: 'Close',		                
			                action: function(dialogItself){
			                    dialogItself.close();
			                }
		            	}
		            ]
		        })).title("Transfer Materials").show(),
				finishTransfer = function(){
					transferAmount = parseInt($("input#materialsAmount").val());
					if (!isNaN(transferAmount)){ done(); dialogItself.modal.close(); }
					else { BootstrapDialog.alert("Invalid amount entered: " + transferAmount); }
				}
				setTimeout(function(){ $("#materialsAmount").focus().bind("keyup", function(e){ if(e.keyCode == 13) { finishTransfer() } }) }, 500);	
			}
		}
		else {
			done();
		}
	}
}